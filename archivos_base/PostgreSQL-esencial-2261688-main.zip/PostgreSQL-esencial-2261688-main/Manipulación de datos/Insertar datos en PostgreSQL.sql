INSERT INTO libro( titulo, "fecha_publicacion", autor_id)
	VALUES ('Mago Vanidoso', '1999-01-08', 2);