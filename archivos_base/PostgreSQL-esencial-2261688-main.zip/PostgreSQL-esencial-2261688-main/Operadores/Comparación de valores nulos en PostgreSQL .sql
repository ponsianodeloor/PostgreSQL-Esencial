INSERT INTO usuario(nombre, apellido, telefono, email)VALUES ('Rooss', 'Rojas', '(123) 7877-4267', 'rossrojas@test.com');
